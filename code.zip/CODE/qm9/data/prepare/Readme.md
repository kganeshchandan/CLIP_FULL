This part of the code is from

"Cormorant: Covariant Molecular Neural Networks"

https://arxiv.org/abs/1906.04015