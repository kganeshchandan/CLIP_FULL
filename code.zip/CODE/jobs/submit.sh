#!/bin/bash

cd ..

python run.py configs/standard/config.yaml
